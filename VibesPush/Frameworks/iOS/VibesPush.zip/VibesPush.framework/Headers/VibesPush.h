//
//  VibesPush.h
//  VibesPush
//
//  Created by Ed Lafoy on 04/10/16.
//  Copyright © 2017 Table XI. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for VibesPush.
FOUNDATION_EXPORT double VibesPushVersionNumber;

//! Project version string for VibesPush.
FOUNDATION_EXPORT const unsigned char VibesPushVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <VibesPush/PublicHeader.h>
